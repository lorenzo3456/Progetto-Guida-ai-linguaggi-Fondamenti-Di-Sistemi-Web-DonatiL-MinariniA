//home pagine database
const Database = {
    template: `
    <section>
        <h2>Cerca Il Nome Del Linguaggio Di Programmazione</h2>
        <!--Div necessario per poter riconoscere lo specifico campo di input-->
        <div>
            <input class="formricerca" type="text" v-model="filtro" placeholder="Cerca linguaggio per titolo...">
            <button @click="getLinguaggi">Cerca</button>
        </div>

        <h2>Tutti I Linguaggi</h2>
        
        <section class="contenitorelinguaggi">
            <article v-for="linguaggio in elencoLinguaggi">
                <img v-bind:src="linguaggio.immagine" :alt="linguaggio.titolo" />
                <h3>{{ linguaggio.titolo }}</h3>
                <p><b>Autore:</b> {{ linguaggio.autore }}</p>
                <p><b>Data:</b> {{ linguaggio.data }}</p>
                <p>{{ linguaggio.testo }}</p>
            </article>
        </section>
    </section>
`,
    data() {
        return {
            elencoLinguaggi: [],
            filtro: ''
        }
    },
    methods: {
        async getLinguaggi() {
            //provo a connettermi al db se no do errore 
            try {
                let response = await fetch(`http://localhost:5000/api/linguaggi/cerca?titolo=${encodeURIComponent(this.filtro)}`);
                let risultato = await response.json();
                this.elencoLinguaggi = risultato;
            } catch (error) {
                console.error("Errore: ", error);
            }
        }
    },
    mounted() {
        this.getLinguaggi();
    }
};

//paragrafo su typescript
const TypeScript = {

    template: `

    <section>

        <article>
            <img src="img/typescript.svg" alt="Logo Typescript" />
            <h1>TypeScript</h1>
            <p>
                <b>TypeScript</b> è un linguaggio di programmazione sviluppato da <b>Microsoft</b> ed è considerato un'<b>estensione di JavaScript</b>.
                Il suo obiettivo principale è rendere il codice più <b>sicuro</b>, <b>leggibile</b> e <b>facile da mantenere</b>, soprattutto nei progetti più grandi.
                Non sostituisce JavaScript, ma lo migliora aggiungendo strumenti utili allo sviluppo.
            </p>
        </article>

        <article>
            <h2>Cos'è un Superset</h2>
            <p>
                TypeScript è un <b>superset di JavaScript</b>, cioè un linguaggio che parte da JavaScript e aggiunge nuove funzionalità.
                Questo significa che tutto il codice JavaScript valido è anche codice TypeScript valido.
                In pratica, TypeScript “espande” JavaScript senza eliminarlo.
            </p>
        </article>

        <article>
            <h2>Tipizzazione</h2>
            <p>
                La caratteristica principale di TypeScript è la <b>tipizzazione statica</b>.
                Questo permette di assegnare un <b>tipo di dato</b> a variabili, parametri e valori di ritorno delle funzioni.
                Ad esempio: numero, stringa, booleano, array.
            </p>
            <p>
                Grazie a questo sistema, molti errori vengono individuati già durante lo sviluppo, prima ancora di eseguire il programma.
                Questo rende il codice più <b>sicuro</b> e riduce i bug.
            </p>
        </article>

        <article>
            <h2>Compilazione</h2>
            <p>
                Il codice TypeScript non viene eseguito direttamente dai browser.
                Deve essere trasformato in <b>JavaScript</b> tramite un processo chiamato <b>compilazione</b>.
            </p>
            <p>
                Questo avviene con il compilatore <b>tsc</b>, che controlla il codice e segnala eventuali errori.
                Solo dopo questa fase il codice può essere eseguito normalmente nei browser o in Node.js.
            </p>
        </article>

        <article>
            <h2>Programmazione ad Oggetti</h2>
            <p>
                TypeScript supporta la <b>programmazione orientata agli oggetti</b>.
                Questo significa che si possono creare <b>classi</b>, <b>oggetti</b>, <b>metodi</b> e <b>proprietà</b>.
            </p>
            <p>
                Inoltre sono presenti concetti importanti come <b>ereditarietà</b> e <b>interfacce</b>, che permettono di riutilizzare il codice e creare strutture più ordinate e pulite.
            </p>
        </article>

        <article>
            <h2>Moduli e Organizzazione del Codice</h2>
            <p>
                TypeScript permette di dividere il codice in <b>moduli</b>.
                Ogni modulo può contenere funzioni, classi o variabili che possono essere <b>esportate</b> e <b>importate</b> in altri file.
            </p>
            <p>
                Questo aiuta a mantenere i progetti ordinati e facilita il lavoro su applicazioni grandi, dove più file devono collaborare tra loro.
            </p>
        </article>

        <article>
            <h2>Componenti</h2>
            <p>
                In TypeScript, soprattutto quando viene usato con <b>Angular</b>, il codice viene organizzato in <b>componenti</b>.
            </p>

            <p>
                Un <b>componente</b> è una parte indipendente dell'applicazione che contiene:
                <b>logica</b> (TypeScript), <b>struttura</b> (HTML) e <b>stile</b> (CSS).
                Ogni componente si occupa di una sola parte dell'interfaccia.
            </p>

            <p>
                Questa divisione permette di non avere un unico file enorme, ma tanti piccoli blocchi separati e riutilizzabili.
                Ad esempio: un componente può essere una navbar, una homepage o un form.
            </p>

            <p>
                I componenti comunicano tra loro passando dati o eventi, ma restano indipendenti.
                Questo rende l'applicazione più ordinata, facile da modificare e più scalabile.
            </p>
        </article>

        <article>
            <h2>Vantaggi</h2>
            <ul>
                <li><b>Codice più sicuro</b> grazie al controllo dei tipi.</li>
                <li><b>Meno errori</b> in fase di sviluppo.</li>
                <li><b>Migliore organizzazione</b> del progetto.</li>
                <li><b>Codice più leggibile</b> e facile da mantenere.</li>
                <li><b>Perfetta integrazione</b> con Angular e altri framework moderni.</li>
            </ul>
        </article>

    </section>

    `
};

//paragrafo su angular
const Angular = {
    template: `
    <section>

        <article>
            <img src="img/logoAngular.png" alt="Logo Angular" />
            <h1>Angular</h1>

            <p>
                <b>Angular</b> è un framework open source creato da Google per sviluppare applicazioni web moderne.
                È usato per costruire siti complessi dove tutto si aggiorna in modo dinamico senza ricaricare la pagina.
            </p>

            <p>
                In Angular tutto è organizzato in componenti, cioè pezzi indipendenti che insieme formano l’applicazione completa.
            </p>
        </article>

        <article>
            <h2>Caratteristiche principali</h2>

            <ul>
                <li>
                    <b>Componenti:</b> l’app è divisa in pezzi indipendenti.
                </li>

                <li>
                    <b>Struttura organizzata:</b> il codice è ordinato e facile da gestire anche in progetti grandi.
                </li>

                <li>
                    <b>Framework completo:</b> Angular include già strumenti per navigazione, dati e interfaccia.
                </li>

                <li>
                    <b>Utilizzo professionale:</b> viene usato spesso in aziende e applicazioni complesse.
                </li>
            </ul>
        

        </article>

        <article>
            <h2>Architettura: Moduli e Componenti</h2>

            <p>
                Angular divide l’applicazione in parti per tenerla organizzata.
            </p>

            <p>
                <b>Moduli:</b> sono contenitori che raggruppano funzionalità simili. Servono per dividere il progetto in sezioni.
            </p>

            <p>
                <b>Componenti:</b> sono le parti visibili dell’app (come una pagina o una sezione).
                Ogni componente contiene HTML, stile e logica.
            </p>
            <img src="img/moduli&componenti.png" alt="Rappresentazione direcotory con gestione moduli e componenti" />
        </article>

        <article>
            <h2>Template e Data Binding</h2>

            <p>
                Il <b>template</b> è la parte HTML del componente, cioè quello che vedi a schermo.
            </p>

            <p>
                Il <b>Data Binding</b> serve a collegare i dati del codice con la pagina.
                In questo modo Angular aggiorna automaticamente ciò che l’utente vede.
            </p>

            <ul>
                <li>
                    <b>Interpolation:</b> mostra un valore dentro la pagina
                </li>

                <li>
                    <b>Property Binding:</b> modifica proprietà HTML come disabled o src.
                </li>

                <li>
                    <b>Event Binding:</b> reagisce alle azioni dell’utente come click o input.
                </li>

                <li>
                    <b>Two-way Binding:</b> collega input e dati in entrambe le direzioni.
                </li>
            </ul>
        </article>

        <article>
            <h2>Direttive</h2>

            <p>
                Le <b>direttive</b> sono istruzioni che modificano il comportamento dell’HTML.
                Permettono di rendere la pagina dinamica senza scrivere JavaScript manuale.
            </p>

            <ul>
                <li>
                    <b>Strutturali:</b> cambiano la struttura della pagina (es. mostra o nascondi elementi).
                </li>

                <li>
                    <b>Di attributo:</b> cambiano l’aspetto o il comportamento di un elemento.
                </li>

                <li>
                    <b>Personalizzate:</b> create dallo sviluppatore per esigenze specifiche.
                </li>
            </ul>
        </article>

        <article>
            <h2>Servizi e Dependency Injection</h2>

            <p>
                I <b>servizi</b> contengono la logica dell’applicazione, cioè le funzioni che non riguardano la grafica.
            </p>

            <p>
                Ad esempio: recuperare dati, salvarli o condividerli tra più componenti.
            </p>

            <p>
                La <b>Dependency Injection</b> è il sistema che permette ad Angular di “dare automaticamente”
                i servizi ai componenti che ne hanno bisogno.
            </p>
        </article>

        <article>
            <h2>Routing</h2>

            <p>
                Il <b>Routing</b> permette di cambiare pagina senza ricaricare il sito.
            </p>

            <p>
                Angular carica solo il contenuto necessario dentro un punto chiamato <b>Router Outlet</b>.
                Questo rende l’app più veloce e simile a un’app mobile.
            </p>

        </article>

        <article>
            <h2>Vantaggi e Svantaggi</h2>

            <h3>Vantaggi</h3>
            <ul>
                <li>Codice organizzato e facile da mantenere.</li>
                <li>Ottimo per applicazioni grandi.</li>
                <li>Componenti riutilizzabili.</li>
                <li>Supportato da Google.</li>
            </ul>

            <h3>Svantaggi</h3>
            <ul>
                <li>Non è semplice da imparare all’inizio.</li>
                <li>Troppo complesso per progetti piccoli.</li>
            </ul>
        </article>

    </section>
    `
};


const Json = {
    data() {
        return {
            datiLinguaggi: null
        }
    },
    template: `
    <section>
        <h2>I linguaggi di programmazione più usati</h2>
        <section class="contenitorelinguaggijson">
            <article v-for="linguaggio in datiLinguaggi" :key="linguaggio.titolo">
                <img v-bind:src="linguaggio.immagine" :alt="linguaggio.titolo" />
                <h3>{{ linguaggio.titolo }}</h3>
                <p><strong>{{ linguaggio.autore }}</strong> - {{ linguaggio.data }}</p>
                <p>{{ linguaggio.testo }}</p>
            </article>
        </section>
    </section>
    `,
    methods: {
        getLinguaggiJson: function () {
            axios.get('linguaggi.json')
                .then(response => {
                    this.datiLinguaggi = response.data;
                });
        }
    },
    mounted() {
        this.getLinguaggiJson();
    }
};

//Gestione CRUD in locale
const Crud = {
    template: `
    <section>
        <h2>CRUD Gestione Linguaggi</h2>

        <article>
            <h3>Lista Linguaggi</h3>
            <ul>
                <li v-for="(linguaggio, index) in linguaggi" :key="index">
                    {{ linguaggio.titolo }}
                </li>
            </ul>
        </article>

        <form @submit.prevent="aggiornaLinguaggio">
            <h2>Modifica / Elimina Linguaggio</h2>
            <ul>
                <li>
                    <label for="linguaggio_selezionato">Linguaggio corrente:</label>
                    <select id="linguaggio_selezionato" v-model="selected" @change="caricaLinguaggioNelForm">
                        <option v-for="(linguaggio, index) in linguaggi" :value="index">
                            {{ linguaggio.titolo }}
                        </option>
                    </select>
                </li>
                <li><label for="titolo">Titolo:</label> <input type="text" id="titolo" v-model="linguaggioInModifica.titolo"/></li>
                <li><label for="autore">Autore:</label> <input type="text" id="autore" v-model="linguaggioInModifica.autore"/></li>
                <li><label for="data">Data:</label> <input type="text" id="data" v-model="linguaggioInModifica.data"/></li>
                <li><label for="immagine">Immagine (link): </label> <input type="text" id="immagine" v-model="linguaggioInModifica.immagine"/></li>
                <li><label for="testo">Testo:</label> <input type="text" id="testo" v-model="linguaggioInModifica.testo"/></li>
                <li>
                    <input type="submit" value="Aggiorna Dati" />
                    <button type="button" @click="cancellaLinguaggioCorrente" class="btn-danger">
                        Elimina Corrente
                    </button>
                </li>
            </ul>
        </form>

        <form @submit.prevent="inserisciLinguaggio">
            <h2>Aggiungi Nuovo Linguaggio</h2>
            <ul>
                <li><label>Titolo:</label> <input type="text" v-model="nuovoLinguaggio.titolo" required /></li>
                <li><label>Autore:</label> <input type="text" v-model="nuovoLinguaggio.autore" required /></li>
                <li><label>Data:</label> <input type="text" v-model="nuovoLinguaggio.data" required /></li>
                <li><label>Immagine (link):</label> <input type="text" v-model="nuovoLinguaggio.immagine" required /></li>
                <li><label>Testo:</label> <input type="text" v-model="nuovoLinguaggio.testo" required /></li>
                <li><input type="submit" value="Inserisci" /></li>
            </ul>
        </form>
    </section>
    `,
    data() {
        return {
            linguaggi: JSON.parse(localStorage.getItem('linguaggi')) || [
                { "titolo": "JavaScript", "autore": "Brendan Eich", "data": "1995", "immagine": "...", "testo": "..." },
                { "titolo": "Python", "autore": "Guido van Rossum", "data": "1991", "immagine": "...", "testo": "..." },
                { "titolo": "C#", "autore": "Microsoft", "data": "2000", "immagine": "...", "testo": "..." }
            ],
            selected: 0,
            linguaggioInModifica: { titolo: '', autore: '', data: '', immagine: '', testo: '' },
            nuovoLinguaggio: { titolo: '', autore: '', data: '', immagine: '', testo: '' }
        }
    },
    mounted() {
        this.caricaLinguaggioNelForm();
    },
    methods: {
        salvaDati() {
            localStorage.setItem('linguaggi', JSON.stringify(this.linguaggi));
        },
        caricaLinguaggioNelForm() {
            if (this.linguaggi.length > 0) {
                this.linguaggioInModifica = { ...this.linguaggi[this.selected] };
            }
        },
        aggiornaLinguaggio() {
            this.linguaggi[this.selected] = { ...this.linguaggioInModifica };
            this.salvaDati();
        },
        inserisciLinguaggio() {
            this.linguaggi.push({ ...this.nuovoLinguaggio });
            this.selected = this.linguaggi.length - 1;
            this.salvaDati();
            this.caricaLinguaggioNelForm();
            this.nuovoLinguaggio = { titolo: '', autore: '', data: '', immagine: '', testo: '' };
        },
        cancellaLinguaggioCorrente() {
            if (this.linguaggi.length === 0) return;
            
            // Eliminazione immediata senza conferme
            this.linguaggi.splice(this.selected, 1);
            
            if (this.selected >= this.linguaggi.length && this.linguaggi.length > 0) {
                this.selected = this.linguaggi.length - 1;
            }
            
            this.salvaDati();
            this.caricaLinguaggioNelForm();
        }
    }
};
//ogni pagina non esiste "realmente" il routes ci permette di convogliare tutto grazie al file js
const routes = [
    { path: "/", component: Database },
    { path: "/Angular", component: Angular },
    { path: "/TypeScript", component: TypeScript },
    { path: "/Json", component: Json },
    { path: "/Crud", component: Crud }
];

const router = VueRouter.createRouter({
    history: VueRouter.createWebHashHistory(),
    routes
});

const app = Vue.createApp({});
app.use(router);
app.mount("#app");