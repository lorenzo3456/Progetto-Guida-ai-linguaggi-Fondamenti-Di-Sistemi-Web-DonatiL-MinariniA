using Microsoft.EntityFrameworkCore;

public class LinguaggiContext : DbContext
{
    public DbSet<Linguaggio> Linguaggi { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Data Source=linguaggi.db");
    }
}