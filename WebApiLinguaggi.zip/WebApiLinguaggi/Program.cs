﻿using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddOpenApi();

builder.Services.AddCors(options =>
    {
        options.AddPolicy("CorsPolicy",
        policyBuilder =>
        {
            policyBuilder.AllowAnyOrigin()
                         .AllowAnyHeader()
                         .AllowAnyMethod();
        });
    }
);

builder.Services.AddDbContext<LinguaggiContext>();

var app = builder.Build();

app.UseCors("CorsPolicy");

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.MapGet("/api/linguaggi", async (LinguaggiContext db) =>
{
    var risultato = from l in db.Linguaggi
                    select new
                    {
                        id = l.Id,
                        autore = l.Autore,
                        data = l.Data,
                        titolo = l.Titolo,
                        immagine = l.Immagine,
                        testo = l.Testo
                    };

    return await risultato.AsNoTracking().ToListAsync();
})
.WithName("GetElencoLinguaggi");

app.MapGet("/api/linguaggi/cerca", async (LinguaggiContext db, string titolo) =>
{
    var risultato = from l in db.Linguaggi
                    where l.Titolo.Contains(titolo)
                    select new
                    {
                        id = l.Id,
                        autore = l.Autore,
                        data = l.Data,
                        titolo = l.Titolo,
                        immagine = l.Immagine,
                        testo = l.Testo
                    };

    return await risultato.AsNoTracking().ToListAsync();
})
.WithName("CercaLinguaggiPerTitolo");

app.MapPost("/api/linguaggi", async (LinguaggiContext db, Linguaggio nuovoLinguaggio) =>
{
    db.Linguaggi.Add(nuovoLinguaggio);
    await db.SaveChangesAsync();
    
    return Results.Ok(nuovoLinguaggio);
})
.WithName("CreaLinguaggio");

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var context = services.GetRequiredService<LinguaggiContext>(); 

    context.Database.EnsureDeleted();
    context.Database.EnsureCreated();

    if (!context.Linguaggi.Any())
    {
        context.Linguaggi.AddRange(
            new Linguaggio
            {
                Titolo = "JavaScript",
                Autore = "Brendan Eich",
                Data = "Primo Posto (Web)",
                Immagine = "https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg",
                Testo = "Il re indiscusso dello sviluppo frontend e del web moderno. Grazie a Node.js è ampiamente utilizzato anche lato server, rimanendo il linguaggio fondamentale e più diffuso per creare interattività sui siti e applicazioni web."
            },
            new Linguaggio
            {
                Titolo = "Python",
                Autore = "Guido van Rossum",
                Data = "Leader AI & Data",
                Immagine = "https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg",
                Testo = "Linguaggio ad alto livello celebre per la sua sintassi pulita, leggibile e simile all'inglese. È lo standard assoluto per l'intelligenza artificiale, il machine learning, data science e automazione."
            },
            new Linguaggio
            {
                Titolo = "TypeScript",
                Autore = "Microsoft",
                Data = "In forte crescita",
                Immagine = "https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-original.svg",
                Testo = "La scelta preferita per i grandi progetti aziendali e framework come Angular. Aggiunge i tipi statici a JavaScript, azzerando i bug strutturali prima ancora che il codice arrivi in produzione nel browser."
            },
            new Linguaggio
            {
                Titolo = "Java",
                Autore = "James Gosling",
                Data = "Standard Enterprise",
                Immagine = "https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg",
                Testo = "Un pilastro della programmazione a oggetti, famoso per il motto 'scrivi una volta, esegui ovunque'. È la spina dorsale dei sistemi bancari, delle grandi infrastrutture aziendali e di moltissime applicazioni backend."
            },
            new Linguaggio
            {
                Titolo = "C#",
                Autore = "Microsoft",
                Data = "Ecosistema .NET",
                Immagine = "https://raw.githubusercontent.com/devicons/devicon/master/icons/csharp/csharp-original.svg",
                Testo = "Linguaggio moderno, potente e strettamente legato al framework .NET ed Entity Framework. Domina lo sviluppo software su Windows, i servizi enterprise e lo sviluppo di videogiochi con Unity."
            },
            new Linguaggio
            {
                Titolo = "SQL",
                Autore = "IBM / ISO",
                Data = "Gestione Database",
                Immagine = "https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original.svg",
                Testo = "Structured Query Language. Non è un linguaggio di programmazione tradizionale, ma è lo standard universale e insostituibile per comunicare con i database relazionali, interrogare dati e strutturare archivi complessi."
            }
        );

        context.SaveChanges();
    }
}

app.Run();