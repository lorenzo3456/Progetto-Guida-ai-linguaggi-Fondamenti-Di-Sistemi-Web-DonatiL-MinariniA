INSTALLARE I SEGUENTI PACCHETTI:
- .NET 9.0 SDK (per versioni superiori è necessaria una conversione del csproj)

NEL TERMINALE:
- dotnet add package Microsoft.EntityFrameworkCore --version 9.0.2
- dotnet add package Microsoft.EntityFrameworkCore.Design --version 9.0.2
- dotnet add package Microsoft.EntityFrameworkCore.Sqlite --version 9.0.2
- dotnet run