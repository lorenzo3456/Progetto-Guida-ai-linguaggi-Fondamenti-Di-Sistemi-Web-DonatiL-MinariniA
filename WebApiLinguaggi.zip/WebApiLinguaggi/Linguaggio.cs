using System.ComponentModel.DataAnnotations;

public class Linguaggio
{
    [Key]
    public int Id { get; set; }

    public string Autore { get; set; } = string.Empty;
    public string Data { get; set; } = string.Empty;
    public string Titolo { get; set; } = string.Empty;
    public string Immagine { get; set; } = string.Empty;
    public string Testo { get; set; } = string.Empty;
}