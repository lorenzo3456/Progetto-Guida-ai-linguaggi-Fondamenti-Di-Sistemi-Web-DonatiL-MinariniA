//home pagine database
const Database = {
    template: `
    <section>
        <h2>Cerca Il Nome Del Linguaggio Di Programmazione</h2>
        <!--Div necessario per poter riconoscere lo specifico campo di input-->
        <div>
            <input class="formricerca" type="text" v-model="filtro" placeholder="Cerca linguaggio per titolo...">
            <button @click="getLinguaggi">Cerca</button>
        </div>

        <h2>Tutti I Linguaggi</h2>
        
        <section class="contenitorelinguaggi">
            <article v-for="linguaggio in elencoLinguaggi">
                <img v-bind:src="linguaggio.immagine" :alt="linguaggio.titolo" />
                <h3>{{ linguaggio.titolo }}</h3>
                <p><b>Autore:</b> {{ linguaggio.autore }}</p>
                <p><b>Data:</b> {{ linguaggio.data }}</p>
                <p>{{ linguaggio.testo }}</p>
            </article>
        </section>
    </section>
`,
    data() {
        return {
            elencoLinguaggi: [],
            filtro: ''
        }
    },
    methods: {
        async getLinguaggi() {
            //provo a connettermi al db se no do errore 
            try {
                let response = await fetch(`http://localhost:5000/api/linguaggi/cerca?titolo=${encodeURIComponent(this.filtro)}`);
                let risultato = await response.json();
                this.elencoLinguaggi = risultato;
            } catch (error) {
                console.error("Errore: ", error);
            }
        }
    },
    mounted() {
        this.getLinguaggi();
    }
};

//paragrafo su typescript
const TypeScript = {
    template: `
    <section>
        <article>
            <h1>TypeScript</h1>
            <p><b>TypeScript</b> è un linguaggio di programmazione sviluppato da <b>Microsoft</b> ed è considerato un'<b>estensione di JavaScript</b>. Il suo obiettivo principale è rendere il codice più <b>sicuro</b>, <b>leggibile</b> e <b>manutenibile</b>, soprattutto nei progetti di medie e grandi dimensioni.</p>
        </article>

        <article>
            <h2>Cos'è un Superset</h2>
            <p>TypeScript è definito un <b>superset di JavaScript</b>, poiché aggiunge nuove funzionalità mantenendo la <b>piena compatibilità</b> con il linguaggio originale. Qualsiasi programma JavaScript valido può essere eseguito anche come programma TypeScript senza modifiche.</p>
        </article>

        <article>
            <h2>Tipizzazione</h2>
            <p>La caratteristica più importante di TypeScript è la <b>tipizzazione</b>. Lo sviluppatore può specificare il <b>tipo di dato</b> associato a variabili, parametri e valori restituiti dalle funzioni. Questo permette al <b>compilatore</b> di rilevare molti errori durante lo sviluppo, prima ancora dell'esecuzione del programma.</p>
        </article>

        <article>
            <h2>Compilazione</h2>
            <p>I browser non sono in grado di eseguire direttamente codice TypeScript. Per questo motivo il codice deve essere convertito in JavaScript tramite il <b>compilatore TypeScript</b>, chiamato <b>tsc</b>. Durante questo processo vengono effettuati <b>controlli sintattici e semantici</b> che contribuiscono ad aumentare l'<b>affidabilità</b> dell'applicazione.</p>
        </article>

        <article>
            <h2>Programmazione ad Oggetti</h2>
            <p>TypeScript supporta pienamente la <b>programmazione orientata agli oggetti</b>. È possibile creare <b>classi</b>, <b>oggetti</b>, <b>costruttori</b>, <b>proprietà</b> e <b>metodi</b>, organizzando il codice in modo più strutturato rispetto al JavaScript tradizionale.</p>
            <p>Sono inoltre disponibili meccanismi come l'<b>ereditarietà</b> e le <b>interfacce</b>, che consentono di riutilizzare il codice e di definire strutture comuni tra più classi.</p>
        </article>

        <article>
            <h2>Moduli e Organizzazione del Codice</h2>
            <p>Per facilitare la gestione dei progetti più complessi, TypeScript permette di suddividere il codice in <b>moduli</b>. Ogni modulo può esportare e importare <b>classi</b>, <b>funzioni</b> e <b>oggetti</b>, favorendo una migliore organizzazione dell'applicazione e una maggiore riusabilità del codice.</p>
        </article>

        <article>
            <h2>Vantaggi</h2>
            <ul>
                <li><b>Maggiore affidabilità</b> del codice.</li>
                <li><b>Riduzione degli errori</b> durante lo sviluppo.</li>
                <li><b>Migliore supporto degli editor</b> tramite IntelliSense.</li>
                <li><b>Codice più leggibile e manutenibile.</b></li>
                <li><b>Ottima integrazione</b> con framework moderni come Angular.</li>
            </ul>
        </article>
    </section>
    `
};

//paragrafo su angular
const Angular = {
    template: `
    <section>
        <article>
            <h1>Angular</h1>
            <p><b>Angular</b> è un <b>framework open source</b> sviluppato da <b>Google</b> per la realizzazione di applicazioni web moderne e dinamiche. È basato principalmente su <b>TypeScript</b> e fornisce una struttura completa per lo sviluppo di applicazioni frontend complesse.</p>
        </article>

        <article>
            <h2>Obiettivi del Framework</h2>
            <p>Angular nasce con l'obiettivo di semplificare lo sviluppo di <b>applicazioni di grandi dimensioni</b>, fornendo strumenti che favoriscono l'<b>organizzazione del codice</b>, il <b>riutilizzo delle funzionalità</b> e la <b>manutenzione nel tempo</b>.</p>
        </article>

        <article>
            <h2>Architettura Modulare</h2>
            <p>Le applicazioni Angular sono organizzate in <b>moduli</b>. Un modulo rappresenta un <b>contenitore logico</b> che raggruppa componenti, servizi e funzionalità correlate. Questa struttura rende il progetto più <b>ordinato</b> e facilmente <b>espandibile</b>.</p>
        </article>

        <article>
            <h2>Componenti</h2>
            <p>I <b>componenti</b> costituiscono l'elemento fondamentale di Angular. Ogni componente è composto da una <b>classe TypeScript</b> e da un <b>template HTML</b> che definisce l'interfaccia grafica visualizzata dall'utente.</p>
            <p>Grazie ai componenti è possibile suddividere l'applicazione in parti <b>indipendenti</b> e <b>riutilizzabili</b>, migliorando la <b>modularità</b> del progetto.</p>
        </article>

        <article>
            <h2>Data Binding</h2>
            <p>Il <b>Data Binding</b> consente la sincronizzazione tra i dati presenti nella classe TypeScript e gli elementi visualizzati nell'interfaccia grafica. Quando i dati cambiano, la vista viene aggiornata automaticamente, migliorando l'<b>interattività</b> dell'applicazione.</p>
        </article>

        <article>
            <h2>Servizi</h2>
            <p>I <b>servizi</b> sono classi utilizzate per gestire funzionalità condivise all'interno dell'applicazione, come la comunicazione con server esterni o la gestione dei dati. Essi permettono di separare la <b>logica applicativa</b> dall'<b>interfaccia utente</b>, rendendo il codice più ordinato e riutilizzabile.</p>
        </article>

        <article>
            <h2>Vantaggi di Angular</h2>
            <ul>
                <li><b>Struttura organizzata e modulare.</b></li>
                <li><b>Elevata riusabilità dei componenti.</b></li>
                <li><b>Ottima integrazione con TypeScript.</b></li>
                <li><b>Facilità nella manutenzione di progetti complessi.</b></li>
                <li><b>Ampia diffusione nello sviluppo professionale.</b></li>
            </ul>
        </article>
    </section>
    `
};
const Json = {
    data() {
        return {
            datiLinguaggi: null
        }
    },
    template: `
    <section>
        <h2>I linguaggi di programmazione più usati</h2>
        <section class="contenitorelinguaggijson">
            <article v-for="linguaggio in datiLinguaggi" :key="linguaggio.titolo">
                <img v-bind:src="linguaggio.immagine" :alt="linguaggio.titolo" />
                <h3>{{ linguaggio.titolo }}</h3>
                <p><strong>{{ linguaggio.autore }}</strong> - {{ linguaggio.data }}</p>
                <p>{{ linguaggio.testo }}</p>
            </article>
        </section>
    </section>
    `,
    methods: {
        getLinguaggiJson: function () {
            axios.get('linguaggi.json')
                .then(response => {
                    this.datiLinguaggi = response.data;
                });
        }
    },
    mounted() {
        this.getLinguaggiJson();
    }
};

//Gestione CRUD in locale
const Crud = {
    template: `
    <section>
        <h2>CRUD Gestione Linguaggi</h2>

        <article>
            <h3>Lista Linguaggi</h3>
            <ul>
                <li v-for="(linguaggio, index) in linguaggi" :key="index">
                    {{ linguaggio.titolo }}
                </li>
            </ul>
        </article>

        <form @submit.prevent="aggiornaLinguaggio">
            <h2>Modifica / Elimina Linguaggio</h2>
            <ul>
                <li>
                    <label for="linguaggio_selezionato">Linguaggio corrente:</label>
                    <select id="linguaggio_selezionato" v-model="selected" @change="caricaLinguaggioNelForm">
                        <option v-for="(linguaggio, index) in linguaggi" :value="index">
                            {{ linguaggio.titolo }}
                        </option>
                    </select>
                </li>
                <li><label for="titolo">Titolo:</label> <input type="text" id="titolo" v-model="linguaggioInModifica.titolo"/></li>
                <li><label for="autore">Autore:</label> <input type="text" id="autore" v-model="linguaggioInModifica.autore"/></li>
                <li><label for="data">Data:</label> <input type="text" id="data" v-model="linguaggioInModifica.data"/></li>
                <li><label for="immagine">Immagine:</label> <input type="text" id="immagine" v-model="linguaggioInModifica.immagine"/></li>
                <li><label for="testo">Testo:</label> <input type="text" id="testo" v-model="linguaggioInModifica.testo"/></li>
                <li>
                    <input type="submit" value="Aggiorna Dati" />
                    <button type="button" @click="cancellaLinguaggioCorrente" class="btn-danger">
                        Elimina Corrente
                    </button>
                </li>
            </ul>
        </form>

        <form @submit.prevent="inserisciLinguaggio">
            <h2>Aggiungi Nuovo Linguaggio</h2>
            <ul>
                <li><label>Titolo:</label> <input type="text" v-model="nuovoLinguaggio.titolo" required /></li>
                <li><label>Autore:</label> <input type="text" v-model="nuovoLinguaggio.autore" required /></li>
                <li><label>Data:</label> <input type="text" v-model="nuovoLinguaggio.data" required /></li>
                <li><label>Immagine:</label> <input type="text" v-model="nuovoLinguaggio.immagine" required /></li>
                <li><label>Testo:</label> <input type="text" v-model="nuovoLinguaggio.testo" required /></li>
                <li><input type="submit" value="Inserisci" /></li>
            </ul>
        </form>
    </section>
    `,
    data() {
        return {
            linguaggi: JSON.parse(localStorage.getItem('linguaggi')) || [
                { "titolo": "JavaScript", "autore": "Brendan Eich", "data": "1995", "immagine": "...", "testo": "..." },
                { "titolo": "Python", "autore": "Guido van Rossum", "data": "1991", "immagine": "...", "testo": "..." },
                { "titolo": "C#", "autore": "Microsoft", "data": "2000", "immagine": "...", "testo": "..." }
            ],
            selected: 0,
            linguaggioInModifica: { titolo: '', autore: '', data: '', immagine: '', testo: '' },
            nuovoLinguaggio: { titolo: '', autore: '', data: '', immagine: '', testo: '' }
        }
    },
    mounted() {
        this.caricaLinguaggioNelForm();
    },
    methods: {
        salvaDati() {
            localStorage.setItem('linguaggi', JSON.stringify(this.linguaggi));
        },
        caricaLinguaggioNelForm() {
            if (this.linguaggi.length > 0) {
                this.linguaggioInModifica = { ...this.linguaggi[this.selected] };
            }
        },
        aggiornaLinguaggio() {
            this.linguaggi[this.selected] = { ...this.linguaggioInModifica };
            this.salvaDati();
        },
        inserisciLinguaggio() {
            this.linguaggi.push({ ...this.nuovoLinguaggio });
            this.selected = this.linguaggi.length - 1;
            this.salvaDati();
            this.caricaLinguaggioNelForm();
            this.nuovoLinguaggio = { titolo: '', autore: '', data: '', immagine: '', testo: '' };
        },
        cancellaLinguaggioCorrente() {
            if (this.linguaggi.length === 0) return;
            
            // Eliminazione immediata senza conferme
            this.linguaggi.splice(this.selected, 1);
            
            if (this.selected >= this.linguaggi.length && this.linguaggi.length > 0) {
                this.selected = this.linguaggi.length - 1;
            }
            
            this.salvaDati();
            this.caricaLinguaggioNelForm();
        }
    }
};
//ogni pagina non esiste "realmente" il routes ci permette di convogliare tutto grazie al file js
const routes = [
    { path: "/", component: Database },
    { path: "/Angular", component: Angular },
    { path: "/TypeScript", component: TypeScript },
    { path: "/Json", component: Json },
    { path: "/Crud", component: Crud }
];

const router = VueRouter.createRouter({
    history: VueRouter.createWebHashHistory(),
    routes
});

const app = Vue.createApp({});
app.use(router);
app.mount("#app");